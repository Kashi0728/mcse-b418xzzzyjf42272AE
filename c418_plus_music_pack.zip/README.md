## Usage Terms

This resource pack is non-commercial and provided as-is.

All configuration and metadata, such as sounds.json and file structure, are created by W_aves

All included music is composed by Daniel Rosenfeld (C418) and remains the property of its original rights holder.

You may use this pack in modpacks or similar projects under the following conditions:
- Credit is clearly given to C418
- A link back to this project is provided
- No monetization or paid distribution of this pack or its contents

Do not rehost or distribute the music files separately.  
Any requests from the rights holder to modify or remove this content will be honored immediately.
